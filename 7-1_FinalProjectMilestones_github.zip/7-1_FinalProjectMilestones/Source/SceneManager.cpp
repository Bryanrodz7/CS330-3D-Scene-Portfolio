///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ================
// This file contains the implementation of the SceneManager class, which is 
// responsible for managing the preparation and rendering of 3D scenes. It 
// handles textures, materials, lighting configurations, and object rendering.
//
// AUTHOR: Bryan [YOUR LAST NAME HERE]
// INSTITUTION: Southern New Hampshire University (SNHU)
// COURSE: CS-330 Computational Graphics and Visualization
//
// INITIAL VERSION: November 1, 2023
// LAST REVISED: December 1, 2024
//
// RESPONSIBILITIES:
// - Load, bind, and manage textures in OpenGL.
// - Define materials and lighting properties for 3D objects.
// - Manage transformations and shader configurations.
// - Render complex 3D scenes using basic meshes.
//
// NOTE: This implementation leverages external libraries like stb_image for 
// texture loading and GLM for matrix and vector operations.
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 *
 *  FIX: the previous version tinted "metal" fully green
 *  (tintAmount = 1.0), which completely hid the metal
 *  texture detail and made every pole render as a flat
 *  solid color instead of a textured surface. The grass
 *  tag was also tinted brown instead of green, so the
 *  ground never looked like grass. Tint amounts below are
 *  lowered so the underlying texture image still shows
 *  through, and the grass tint now actually reads green.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);

		glm::vec3 textureTint = glm::vec3(1.0f, 1.0f, 1.0f);
		float textureTintAmount = 0.0f;

		if (textureTag.compare("grass") == 0)
		{
			// light green tint so the ground texture still reads as grass
			textureTint = glm::vec3(0.45f, 0.65f, 0.30f);
			textureTintAmount = 0.35f;
		}
		else if (textureTag.compare("metal") == 0)
		{
			// strong green tint on the metal poles/ladder/arch so they
			// actually read as green like the reference photo's steel
			// uprights. Previous tintAmount of 0.35 was too weak and
			// the underlying gray metal texture was washing it out to
			// a flat gray instead of green.
			textureTint = glm::vec3(0.05f, 0.42f, 0.10f);
			textureTintAmount = 0.85f;
		}
		else if (textureTag.compare("plastic") == 0)
		{
			// flat, slightly desaturated matte yellow tint for the
			// roof, slide, and railings -- less glossy/saturated than
			// pure bright yellow so it reads as matte plastic
			textureTint = glm::vec3(0.80f, 0.68f, 0.18f);
			textureTintAmount = 0.55f;
		}
		else if (textureTag.compare("darkgray") == 0)
		{
			// dark neutral gray tint for the platform deck and stair
			// treads, matching the dark gray steel deck/stairs in the
			// reference photo instead of bright yellow plastic
			textureTint = glm::vec3(0.22f, 0.22f, 0.24f);
			textureTintAmount = 0.80f;
		}

		m_pShaderManager->setVec3Value("textureTint", textureTint);
		m_pShaderManager->setFloatValue("textureTintAmount", textureTintAmount);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method defines the diffuse, specular, and shininess
 *  values used by the Phong lighting model for each texture.
 *
 *  ADDED: a "darkPlasticMaterial" for the stair treads so the
 *  stairs read as a separate dark material from the wood deck,
 *  matching the dark gray stairs in the reference photo.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL material;

	m_objectMaterials.clear();

	// grass material for the textured ground plane
	material.diffuseColor = glm::vec3(0.85f, 0.85f, 0.85f);
	material.specularColor = glm::vec3(0.20f, 0.20f, 0.20f);
	material.shininess = 16.0f;
	material.tag = "grassMaterial";
	m_objectMaterials.push_back(material);

	// wood material for the platform deck
	material.diffuseColor = glm::vec3(0.82f, 0.82f, 0.82f);
	material.specularColor = glm::vec3(0.28f, 0.28f, 0.28f);
	material.shininess = 24.0f;
	material.tag = "woodMaterial";
	m_objectMaterials.push_back(material);

	// metal material for the poles, ladder, and round handle
	material.diffuseColor = glm::vec3(0.88f, 0.88f, 0.88f);
	material.specularColor = glm::vec3(0.95f, 0.95f, 0.95f);
	material.shininess = 96.0f;
	material.tag = "metalMaterial";
	m_objectMaterials.push_back(material);

	// plastic material for the roof, slide, and railings
	material.diffuseColor = glm::vec3(0.90f, 0.90f, 0.90f);
	material.specularColor = glm::vec3(0.65f, 0.65f, 0.65f);
	material.shininess = 48.0f;
	material.tag = "plasticMaterial";
	m_objectMaterials.push_back(material);

	// dark, low-gloss material for the stair treads so they
	// read as a separate dark gray surface, like the reference photo,
	// instead of matching the wood deck color
	material.diffuseColor = glm::vec3(0.15f, 0.15f, 0.16f);
	material.specularColor = glm::vec3(0.30f, 0.30f, 0.30f);
	material.shininess = 12.0f;
	material.tag = "darkPlasticMaterial";
	m_objectMaterials.push_back(material);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method configures a warm directional sunlight and
 *  two softer fill lights so the playground remains visible
 *  from every camera angle without areas of complete shadow.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	// enable the Phong lighting calculations in the fragment shader
	m_pShaderManager->setIntValue(g_UseLightingName, true);

	// warm outdoor sunlight shining down across the playground
	m_pShaderManager->setVec3Value("directionalLight.direction", glm::vec3(-0.45f, -1.0f, -0.35f));
	m_pShaderManager->setVec3Value("directionalLight.ambient", glm::vec3(0.24f, 0.22f, 0.18f));
	m_pShaderManager->setVec3Value("directionalLight.diffuse", glm::vec3(0.78f, 0.72f, 0.58f));
	m_pShaderManager->setVec3Value("directionalLight.specular", glm::vec3(0.95f, 0.90f, 0.78f));
	m_pShaderManager->setIntValue("directionalLight.bActive", true);

	// warm point light adds highlights to the front and top surfaces
	m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(4.0f, 6.5f, 4.5f));
	m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.04f, 0.035f, 0.03f));
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(0.28f, 0.24f, 0.18f));
	m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(0.45f, 0.40f, 0.30f));
	m_pShaderManager->setIntValue("pointLights[0].bActive", true);

	// cool fill light keeps the back side of the structure visible
	m_pShaderManager->setVec3Value("pointLights[1].position", glm::vec3(-4.5f, 4.0f, -3.5f));
	m_pShaderManager->setVec3Value("pointLights[1].ambient", glm::vec3(0.03f, 0.035f, 0.045f));
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", glm::vec3(0.18f, 0.22f, 0.30f));
	m_pShaderManager->setVec3Value("pointLights[1].specular", glm::vec3(0.22f, 0.28f, 0.38f));
	m_pShaderManager->setIntValue("pointLights[1].bActive", true);

	// unused point lights and the spotlight remain disabled
	m_pShaderManager->setIntValue("pointLights[2].bActive", false);
	m_pShaderManager->setIntValue("pointLights[3].bActive", false);
	m_pShaderManager->setIntValue("pointLights[4].bActive", false);
	m_pShaderManager->setIntValue("spotLight.bActive", false);
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	CreateGLTexture("textures/wood.jpg", "wood");
	CreateGLTexture("textures/metal.jpg", "metal");
	CreateGLTexture("textures/plastic.jpg", "plastic");
	// same image file as "plastic" but registered under a second tag
	// so the dark gray deck/stairs can use a different tint amount
	// than the yellow roof/railings without fighting over one tag
	CreateGLTexture("textures/plastic.jpg", "darkgray");
	CreateGLTexture("textures/grass.jpg", "grass");
	BindGLTextures();

	// define the surface properties and lights used by the Phong shader
	DefineObjectMaterials();
	SetupSceneLights();

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadPyramid4Mesh();
	m_basicMeshes->LoadTorusMesh();
}


/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 *
 *  REBUILT so every connecting object (stairs, slide,
 *  railings, ladder, arch climber) is positioned using the
 *  platform's actual edge coordinates instead of standalone
 *  guessed numbers. This removes the floating/disconnected
 *  pieces from the previous version. Platform reference:
 *    platform box: scale (4.0, 0.25, 2.8), position (0, 1.75, 0)
 *    -> top surface Y  = 1.875
 *    -> right edge  X  = 2.0
 *    -> left edge   X  = -2.0
 *    -> front edge  Z  = 1.4
 *    -> back edge   Z  = -1.4
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// large flat ground plane for the playground area
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("grass");
	SetShaderMaterial("grassMaterial");
	SetTextureUVScale(8.0f, 8.0f);
	m_basicMeshes->DrawPlaneMesh();

	// raised platform deck for the playground structure
	scaleXYZ = glm::vec3(4.0f, 0.25f, 2.8f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 1.75f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("darkgray");
	SetShaderMaterial("darkPlasticMaterial");
	SetTextureUVScale(2.0f, 2.0f);
	m_basicMeshes->DrawBoxMesh();

	// ---------------------------------------------------------------
	// SUPPORT POLES: 4 lower posts (ground to platform) + 4 upper
	// posts (platform to roof), all green, all touching ground at
	// Y=0 and reaching the roof at Y=4.0 with no gap
	// ---------------------------------------------------------------

	// front left green support pole - lower section ground to platform
	scaleXYZ = glm::vec3(0.18f, 1.75f, 0.18f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-1.8f, 0.0f, 1.2f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("metal");
	SetShaderMaterial("metalMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// front right green support pole - lower section ground to platform
	scaleXYZ = glm::vec3(0.18f, 1.75f, 0.18f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(1.8f, 0.0f, 1.2f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("metal");
	SetShaderMaterial("metalMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// back left green support pole - lower section ground to platform
	scaleXYZ = glm::vec3(0.18f, 1.75f, 0.18f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-1.8f, 0.0f, -1.2f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("metal");
	SetShaderMaterial("metalMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// back right green support pole - lower section ground to platform
	scaleXYZ = glm::vec3(0.18f, 1.75f, 0.18f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(1.8f, 0.0f, -1.2f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("metal");
	SetShaderMaterial("metalMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// front left green support pole - upper section platform to roof
	scaleXYZ = glm::vec3(0.18f, 2.1f, 0.18f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-1.8f, 1.75f, 1.2f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("metal");
	SetShaderMaterial("metalMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// front right green support pole - upper section platform to roof
	scaleXYZ = glm::vec3(0.18f, 2.1f, 0.18f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(1.8f, 1.75f, 1.2f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("metal");
	SetShaderMaterial("metalMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// back left green support pole - upper section platform to roof
	scaleXYZ = glm::vec3(0.18f, 2.1f, 0.18f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-1.8f, 1.75f, -1.2f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("metal");
	SetShaderMaterial("metalMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// back right green support pole - upper section platform to roof
	scaleXYZ = glm::vec3(0.18f, 2.1f, 0.18f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(1.8f, 1.75f, -1.2f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("metal");
	SetShaderMaterial("metalMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// clean symmetric pyramid roof, sized to slightly overhang the
	// 4 upper posts (posts sit at +/-1.8, +/-1.2 -- roof footprint
	// is wider than that on both axes so the eaves overhang evenly)
	scaleXYZ = glm::vec3(5.0f, 1.2f, 4.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 4.35f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(2.0f, 2.0f);
	m_basicMeshes->DrawPyramid4Mesh();

	// ---------------------------------------------------------------
	// SLIDE: straight slide bed attached directly to the platform's
	// left edge (X = -2.0, top surface Y = 1.875), angled down to
	// the ground, with two raised side rails running the full length
	// so it matches the product reference (open slide with side
	// guards, not a closed tube)
	// ---------------------------------------------------------------

	// slide bed - flat panel from the platform edge down to the ground
	scaleXYZ = glm::vec3(0.85f, 0.10f, 4.3f);
	XrotationDegrees = -28.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.95f, 0.95f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 3.0f);
	m_basicMeshes->DrawBoxMesh();

	// slide left side rail - same rotation as the bed so it stays
	// parallel along the slide's left edge
	scaleXYZ = glm::vec3(0.10f, 0.10f, 4.3f);
	XrotationDegrees = -28.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.95f, 1.32f, -0.42f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 3.0f);
	m_basicMeshes->DrawBoxMesh();

	// slide right side rail - mirrors the left rail
	scaleXYZ = glm::vec3(0.10f, 0.10f, 4.3f);
	XrotationDegrees = -28.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.95f, 1.32f, 0.42f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 3.0f);
	m_basicMeshes->DrawBoxMesh();

	// ---------------------------------------------------------------
	// STAIRS: 3 individual steps, each with the same fixed rise
	// height, stacked so each one sits ON TOP of the one before it
	// (not overlapping/containing it like the previous version did).
	// A small landing platform sits between the top step and the
	// main deck, matching the intermediate landing visible in the
	// reference photo instead of the top step touching the main
	// platform directly.
	// ---------------------------------------------------------------

	// bottom stair step - sits on the ground
	scaleXYZ = glm::vec3(1.0f, 0.45f, 0.55f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(2.5f, 0.225f, 2.25f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("darkgray");
	SetShaderMaterial("darkPlasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// middle stair step - sits directly on top of the bottom step
	// (top of bottom step = 0.225 + 0.225 = 0.45, so this step's
	// bottom starts exactly there with no gap and no overlap)
	scaleXYZ = glm::vec3(1.0f, 0.45f, 0.55f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(2.5f, 0.675f, 1.70f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("darkgray");
	SetShaderMaterial("darkPlasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// top stair step - sits directly on top of the middle step
	// (top of middle step = 0.675 + 0.225 = 0.90)
	scaleXYZ = glm::vec3(1.0f, 0.45f, 0.55f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(2.5f, 1.125f, 1.15f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("darkgray");
	SetShaderMaterial("darkPlasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// small landing platform between the top step and the main deck
	// (top of top step = 1.125 + 0.225 = 1.35, landing bottom starts
	// there and its top reaches exactly 1.875 to meet the main
	// platform's height with no gap or overlap)
	scaleXYZ = glm::vec3(1.1f, 0.525f, 1.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(2.5f, 1.6125f, 0.65f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("darkgray");
	SetShaderMaterial("darkPlasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// yellow trim strip along the landing's front edge (the edge
	// facing the stairs), matching the yellow-trimmed dark stairs
	// in the reference photo
	scaleXYZ = glm::vec3(1.1f, 0.03f, 0.06f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(2.5f, 1.89f, 1.13f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// yellow trim strip on each individual step's front edge for
	// visual separation between steps, matching the reference photo
	scaleXYZ = glm::vec3(1.0f, 0.03f, 0.06f);
	positionXYZ = glm::vec3(2.5f, 0.465f, 2.51f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(2.5f, 0.915f, 1.96f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(2.5f, 1.365f, 1.41f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// ---------------------------------------------------------------
	// STAIR HANDRAIL: angled rail running along the outer edge of the
	// stairs (X = 3.05), matching the stair slope from the bottom
	// step up to the landing, plus 2 short vertical support posts
	// holding it up. Slope calculated from the actual stair geometry:
	// bottom step front-bottom (Z=2.775, Y=0) to top step front-top
	// (Z=0.875, Y=1.35) -- rail length 2.33, angled 54.6 degrees.
	// ---------------------------------------------------------------

	// angled top handrail
	scaleXYZ = glm::vec3(0.06f, 0.06f, 2.33f);
	XrotationDegrees = 54.6f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.05f, 1.075f, 1.825f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// vertical support post near the bottom of the stairs
	scaleXYZ = glm::vec3(0.06f, 0.45f, 0.06f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.05f, 0.225f, 2.25f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// vertical support post near the top of the stairs, by the landing
	scaleXYZ = glm::vec3(0.06f, 0.9f, 0.06f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.05f, 0.675f, 1.15f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// ---------------------------------------------------------------
	// SUPPORT BEAM at the open side of the platform (the side without
	// a vertical pole at the corner) -- a diagonal brace that actually
	// touches both the ground and the underside of the platform
	// instead of floating in open air
	// ---------------------------------------------------------------
	scaleXYZ = glm::vec3(0.10f, 0.10f, 2.0f);
	XrotationDegrees = -42.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(2.5f, 0.85f, 0.55f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// ---------------------------------------------------------------
	// RAILINGS: top rail + bottom rail on all 4 sides of the platform,
	// flush with the platform edges (X = +/-2.0, Z = +/-1.4). Each
	// side that has a connecting feature (ladder on the front, slide
	// on the left, stairs on the right) is split into two shorter
	// segments with a gap left open at that feature's location, so
	// there is an actual opening to climb through instead of a solid
	// unbroken bar blocking entry.
	// ---------------------------------------------------------------

	// front top railing - split into two segments with a gap centered
	// on the ladder (ladder spans X = -1.58 to -0.82, gap center -1.2)
	scaleXYZ = glm::vec3(0.75f, 0.06f, 0.06f);
	positionXYZ = glm::vec3(1.4f, 2.5f, 1.4f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(1.85f, 0.06f, 0.06f);
	positionXYZ = glm::vec3(-0.075f, 2.5f, 1.4f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// front bottom railing - same gap as the top railing above
	scaleXYZ = glm::vec3(0.75f, 0.06f, 0.06f);
	positionXYZ = glm::vec3(1.4f, 2.1f, 1.4f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(1.85f, 0.06f, 0.06f);
	positionXYZ = glm::vec3(-0.075f, 2.1f, 1.4f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// back top railing - no connecting feature on this side, stays
	// as one solid bar
	scaleXYZ = glm::vec3(4.0f, 0.06f, 0.06f);
	positionXYZ = glm::vec3(0.0f, 2.5f, -1.4f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// back bottom railing
	scaleXYZ = glm::vec3(4.0f, 0.06f, 0.06f);
	positionXYZ = glm::vec3(0.0f, 2.1f, -1.4f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// right side top railing - split into two segments with a gap
	// where the stairs meet the platform (stairs are centered at
	// Z = 1.4 to 2.0, against the front-right corner)
	scaleXYZ = glm::vec3(0.06f, 0.06f, 1.4f);
	positionXYZ = glm::vec3(2.0f, 2.5f, -0.7f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 2.0f);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(0.06f, 0.06f, 0.7f);
	positionXYZ = glm::vec3(2.0f, 2.5f, 0.65f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 2.0f);
	m_basicMeshes->DrawBoxMesh();

	// right side bottom railing - same gap as the top railing above
	scaleXYZ = glm::vec3(0.06f, 0.06f, 1.4f);
	positionXYZ = glm::vec3(2.0f, 2.1f, -0.7f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 2.0f);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(0.06f, 0.06f, 0.7f);
	positionXYZ = glm::vec3(2.0f, 2.1f, 0.65f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 2.0f);
	m_basicMeshes->DrawBoxMesh();

	// left side top railing - split into two segments with a gap
	// where the slide attaches to the platform edge (slide is
	// centered on Z = 0, full platform depth)
	scaleXYZ = glm::vec3(0.06f, 0.06f, 0.9f);
	positionXYZ = glm::vec3(-2.0f, 2.5f, 0.95f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 2.0f);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(0.06f, 0.06f, 0.9f);
	positionXYZ = glm::vec3(-2.0f, 2.5f, -0.95f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 2.0f);
	m_basicMeshes->DrawBoxMesh();

	// left side bottom railing - same gap as the top railing above
	scaleXYZ = glm::vec3(0.06f, 0.06f, 0.9f);
	positionXYZ = glm::vec3(-2.0f, 2.1f, 0.95f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 2.0f);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(0.06f, 0.06f, 0.9f);
	positionXYZ = glm::vec3(-2.0f, 2.1f, -0.95f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 2.0f);
	m_basicMeshes->DrawBoxMesh();

	// vertical bars on the front railing's solid segments, evenly
	// spaced within each segment, avoiding the ladder gap between
	// X = -1.58 and X = -0.075
	scaleXYZ = glm::vec3(0.05f, 0.45f, 0.05f);
	positionXYZ = glm::vec3(-0.65f, 2.3f, 1.4f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(0.05f, 0.45f, 0.05f);
	positionXYZ = glm::vec3(0.7f, 2.3f, 1.4f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(0.05f, 0.45f, 0.05f);
	positionXYZ = glm::vec3(1.4f, 2.3f, 1.4f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// ---------------------------------------------------------------
	// ARCH CLIMBER: repositioned to stand upright in the railing gap
	// above the stairs/landing (X = 2.0, gap spans Z = 0.65 to 1.4),
	// so it frames the opening like an entrance arch someone climbs
	// through to step from the landing onto the main platform,
	// instead of lying flat against the platform edge.
	// ---------------------------------------------------------------
	scaleXYZ = glm::vec3(0.45f, 0.45f, 0.08f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(2.0f, 2.05f, 1.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("metal");
	SetShaderMaterial("metalMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawTorusMesh();

	// ---------------------------------------------------------------
	// LADDER: moved to the front-left corner near the slide (instead
	// of front-center), matching the reference photo where the
	// ladder sits offset to one side rather than centered. Both
	// uprights touch the ground at Y=0 and reach the platform's
	// front edge at Y=1.875. Uprights stay green metal (matching the
	// other support poles); rungs are yellow plastic, matching the
	// yellow-rung ladder visible in the reference photo.
	// ---------------------------------------------------------------

	// left upright post of the front-left ladder
	scaleXYZ = glm::vec3(0.07f, 1.875f, 0.07f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-1.58f, 0.0f, 1.4f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("metal");
	SetShaderMaterial("metalMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// right upright post of the front-left ladder
	scaleXYZ = glm::vec3(0.07f, 1.875f, 0.07f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-0.82f, 0.0f, 1.4f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("metal");
	SetShaderMaterial("metalMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// bottom rung - yellow plastic
	scaleXYZ = glm::vec3(0.75f, 0.07f, 0.07f);
	positionXYZ = glm::vec3(-1.2f, 0.45f, 1.4f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// middle rung - yellow plastic
	scaleXYZ = glm::vec3(0.75f, 0.07f, 0.07f);
	positionXYZ = glm::vec3(-1.2f, 0.95f, 1.4f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// top rung, just below the platform edge - yellow plastic
	scaleXYZ = glm::vec3(0.75f, 0.07f, 0.07f);
	positionXYZ = glm::vec3(-1.2f, 1.45f, 1.4f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// ---------------------------------------------------------------
	// TIC-TAC-TOE PANEL: lower back face between the back-left and
	// back-right posts (X = -1.8 to 1.8, Z = -1.2). Backing panel
	// plus a 3x3 grid of 9 small rolling disc tiles, matching the
	// tic-tac-toe activity panel from the product reference photo.
	// ---------------------------------------------------------------

	// dark gray backing panel for the tic-tac-toe activity panel
	scaleXYZ = glm::vec3(3.2f, 0.85f, 0.05f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.95f, -1.2f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("darkgray");
	SetShaderMaterial("darkPlasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// row 1 (top row) of rolling disc tiles - left, center, right
	scaleXYZ = glm::vec3(0.16f, 0.16f, 0.04f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-0.85f, 1.25f, -1.17f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	positionXYZ = glm::vec3(0.0f, 1.25f, -1.17f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	positionXYZ = glm::vec3(0.85f, 1.25f, -1.17f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// row 2 (middle row) of rolling disc tiles - left, center, right
	positionXYZ = glm::vec3(-0.85f, 0.95f, -1.17f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	positionXYZ = glm::vec3(0.0f, 0.95f, -1.17f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	positionXYZ = glm::vec3(0.85f, 0.95f, -1.17f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// row 3 (bottom row) of rolling disc tiles - left, center, right
	positionXYZ = glm::vec3(-0.85f, 0.65f, -1.17f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	positionXYZ = glm::vec3(0.0f, 0.65f, -1.17f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	positionXYZ = glm::vec3(0.85f, 0.65f, -1.17f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// guard wall bars above the tic-tac-toe panel, connecting the
	// panel top to the underside of the platform
	scaleXYZ = glm::vec3(0.05f, 0.65f, 0.05f);
	positionXYZ = glm::vec3(-1.2f, 1.55f, -1.2f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(0.0f, 1.55f, -1.2f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(1.2f, 1.55f, -1.2f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// ---------------------------------------------------------------
	// FINGER MAZE PANEL: lower right face between the front-right and
	// back-right posts (X = 1.8, Z = -1.2 to 1.2). Same panel size as
	// the tic-tac-toe panel, dark gray backing only -- the maze line
	// pattern itself is a printed/molded design on the real product,
	// not a separate 3D shape, so it is represented as a flat panel.
	// ---------------------------------------------------------------
	scaleXYZ = glm::vec3(0.05f, 0.85f, 2.2f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(1.8f, 0.95f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("darkgray");
	SetShaderMaterial("darkPlasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// guard wall bars above the finger maze panel
	scaleXYZ = glm::vec3(0.05f, 0.65f, 0.05f);
	positionXYZ = glm::vec3(1.8f, 1.55f, -0.7f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(1.8f, 1.55f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(1.8f, 1.55f, 0.7f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// ---------------------------------------------------------------
	// YELLOW SLAT WALL: lower front face, on the open side between
	// the front-left and front-right posts (X = -1.8 to 1.8, Z = 1.2),
	// same size as the other two lower panels. Backing panel plus 5
	// thin vertical yellow slats, matching the yellow vertical-slat
	// guard wall visible on the open side of the reference photo.
	// ---------------------------------------------------------------

	// yellow backing panel
	scaleXYZ = glm::vec3(3.2f, 0.85f, 0.05f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.95f, 1.2f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// 5 evenly spaced vertical slats across the yellow wall panel
	scaleXYZ = glm::vec3(0.07f, 0.80f, 0.07f);
	positionXYZ = glm::vec3(-1.5f, 0.95f, 1.17f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(-0.45f, 0.95f, 1.17f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(0.2f, 0.95f, 1.17f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(0.85f, 0.95f, 1.17f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(1.5f, 0.95f, 1.17f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("plastic");
	SetShaderMaterial("plasticMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();
}