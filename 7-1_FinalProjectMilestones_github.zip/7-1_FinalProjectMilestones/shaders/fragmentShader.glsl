#version 330 core
out vec4 fragmentColor;
in vec3 fragmentPosition;
in vec3 fragmentVertexNormal;
in vec2 fragmentTextureCoordinate;
struct Material
{
vec3 diffuseColor;
vec3 specularColor;
float shininess;
};
struct DirectionalLight
{
vec3 direction;
vec3 ambient;
vec3 diffuse;
vec3 specular;
bool bActive;
};
struct PointLight
{
vec3 position;
vec3 ambient;
vec3 diffuse;
vec3 specular;
bool bActive;
};
#define TOTAL_POINT_LIGHTS 5
uniform bool bUseTexture;
uniform bool bUseLighting;
uniform vec4 objectColor;
uniform vec3 viewPosition;
uniform DirectionalLight directionalLight;
uniform PointLight pointLights[TOTAL_POINT_LIGHTS];
uniform Material material;
uniform sampler2D objectTexture;
uniform vec2 UVscale;
uniform vec3 textureTint;
uniform float textureTintAmount;
void main()
{
vec4 surfaceColor = objectColor;
if (bUseTexture)
{
vec4 sampledColor = texture(objectTexture, fragmentTextureCoordinate * UVscale);
float brightness = dot(sampledColor.rgb, vec3(0.299, 0.587, 0.114));
vec3 tintedColor = brightness * textureTint;
surfaceColor = vec4(mix(sampledColor.rgb, tintedColor, textureTintAmount), sampledColor.a);
}
if (!bUseLighting)
{
fragmentColor = surfaceColor;
}
else
{
vec3 normalVector = normalize(fragmentVertexNormal);
vec3 viewDirection = normalize(viewPosition - fragmentPosition);
vec3 finalLighting = surfaceColor.rgb * 0.20;
if (directionalLight.bActive)
{
vec3 lightDirection = normalize(-directionalLight.direction);
float diffuseValue = max(dot(normalVector, lightDirection), 0.0);
vec3 reflectionDirection = reflect(-lightDirection, normalVector);
float specularValue = pow(max(dot(viewDirection, reflectionDirection), 0.0), max(material.shininess, 1.0));
finalLighting = finalLighting + directionalLight.ambient * surfaceColor.rgb;
finalLighting = finalLighting + directionalLight.diffuse * diffuseValue * material.diffuseColor * surfaceColor.rgb;
finalLighting = finalLighting + directionalLight.specular * specularValue * material.specularColor;
}
for (int i = 0; i < TOTAL_POINT_LIGHTS; i++)
{
if (pointLights[i].bActive)
{
vec3 pointDirection = normalize(pointLights[i].position - fragmentPosition);
float pointDiffuse = max(dot(normalVector, pointDirection), 0.0);
vec3 pointReflection = reflect(-pointDirection, normalVector);
float pointSpecular = pow(max(dot(viewDirection, pointReflection), 0.0), max(material.shininess, 1.0));
finalLighting = finalLighting + pointLights[i].ambient * surfaceColor.rgb;
finalLighting = finalLighting + pointLights[i].diffuse * pointDiffuse * material.diffuseColor * surfaceColor.rgb;
finalLighting = finalLighting + pointLights[i].specular * pointSpecular * material.specularColor;
}
}
fragmentColor = vec4(clamp(finalLighting, 0.0, 1.0), surfaceColor.a);
}
}
